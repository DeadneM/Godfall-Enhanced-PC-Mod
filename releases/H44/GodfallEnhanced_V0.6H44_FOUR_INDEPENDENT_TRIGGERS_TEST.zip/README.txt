Godfall Enhanced V0.6H44 - FOUR SEPARATE TRIGGERS
EXPERIMENTAL. Back up H41 and do NOT retest H43.

H44 is based on H41; no crashing H43 auto-chain remains.
Hotkeys, separately activated (no F1 menu required):
 F6 = H25 proven visual Macros materials
 F7 = attempt temporary Hinterclaw Alcove cosmetic TMap insert (HIGH RISK)
 F8 = attempt local APCosmeticsManager override (HIGH RISK)
 F9 = attempt native Alcove cosmetic preview (HIGH RISK)
 F10 = best-effort removal of H44 map/override/visual changes

F1 overlay METHOD C: display key help, makes NO native mutations.
F1 Method A/B remain the original validated H25 visual controls.

If key registration fails or your game uses an F-key, manually enter
one of these commands in ue4ss/Mods/GodfallEnhancedBridge/bridge_command.txt:
 H44_VISUAL, H44_MAP, H44_OVERRIDE, H44_PREVIEW, H44_REVERT

TO TEST:
1. Extract full ZIP beside Aperion-Win64-Shipping.exe and restart.
2. Equip Hinterclaw and enter fully loaded Sanctum.
3. Press only ONE trigger, check original game's skin menu.
4. If F7/F8/F9 triggers a crash, DO NOT retry it. Send log.
5. F10 attempts undo only for completed local modifications; re-enter
   Sanctum to reset an Alcove preview if needed.

CAUTION: F7 soft-class coercion, F8 synthetic tag filter struct,
and F9 guessed Blueprint parameters are unverified native calls.
Lua pcall does NOT prevent a C++ access violation. Test only if
willing to accept game crashes. No save/account/backend grants.
No genuine Macros native unlock has yet been demonstrated.

All binaries (GodfallEnhanced.asi, dxgi.dll) retained from H41.
https://github.com/DeadneM/Godfall-Enhanced-PC-Mod/tree/dev/h44-four-independent-triggers
