Godfall Enhanced V0.6H28 - Acquisition Path Audit / F1 overlay TEST

Place contents of ZIP directly in the directory containing
Aperion-Win64-Shipping.exe, preserving the ue4ss/ subdirectory.
Back up your existing mod files before overwriting.

F1 - Toggle overlay (same key as H27).
Method A - Apply the Macros appearance on Hinterclaw.
Method B - Restore materials via stable parent assets (H25 safety fix).
Method C - Dump materials and perform the H28 TARGETED READ-ONLY audit.
Press C once; send GodfallEnhancedBridge.log.

New in H28: scan specifically APLocalPlayer, APCosmeticsManager,
APLootManagerComponent, APInventoryComponent, and other relevant
native classes. Unlike H27, functions on the local player cannot
be lost behind a 360-function global cap consumed by inventory.

Results to look for: H28_UNLOCK_AUDIT_BEGIN, H28_FUNCTION,
H28_PARAM, H28_PROPERTY, H28_UNLOCK_AUDIT_END.

The mod does NOT yet unlock Gratitude Pack or all cosmetics.
No entitlement, saves, or server/account reward state is modified.
This is a candidate for TESTING. It was not yet validated in game.

Code and detailed notes:
https://github.com/DeadneM/Godfall-Enhanced-PC-Mod/tree/dev/h28-acquisition-path-audit
