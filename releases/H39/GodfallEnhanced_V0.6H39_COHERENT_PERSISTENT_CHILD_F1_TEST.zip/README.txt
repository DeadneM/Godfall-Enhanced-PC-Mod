Godfall Enhanced V0.6H39 - PERSISTENT COHERENT CHILD AUDIT

EXPERIMENTAL READ-ONLY DIAGNOSTIC. NOT A NATIVE SKIN UNLOCK.

H38 verified WBP_GT_Test_C loaded with original skins menu.
Its CoherentUIGTWidget_Persistent_90 ObjectProperty points to the
specific plugin UI component. H39 reads that property directly.

INSTALL:
Backup H38. Extract this ZIP beside Aperion-Win64-Shipping.exe,
preserving ue4ss folders. Restart Godfall.

TEST:
1) In fully loaded Sanctum, before skins UI, press F1 -> C once.
2) Open the ORIGINAL Hinterclaw skins menu.
3) Press F1 -> C again with vanilla skin screen active.
4) Send GodfallEnhancedBridge.log before game restart.
Look for H39_BOOT_MARKER=OK, H39_CHILD_PROPERTY,
H39_CHILD_OWNERSHIP, H39_CHILD_ROUTE, H39_CHILD_FUNCTION,
H39_CHILD_PROPERTY depth=, H39_CHILD_META_END, H39_CHILD_PROBE_END.

A/B visual material methods (H25), F1 overlay, H35 offline
frontend locator, dxgi.dll and GodfallEnhanced.asi are retained.
Previous H38 host audit may be triggered by manual GT_HOST_METADATA
command; H36 map audit by ALCOVE_MAP_AUDIT; H34 watcher by COHERENT_PROBE.

No JS calls, gameplay state/skin ownership modification, TMap edits,
network/backend calls, save edits or raw HTTP URL logging.
Reflection on live Unreal objects carries residual engine crash risk.

If the child exposes only generic Coherent widget APIs, the next
step is FModel WBP_GT_Test and frontend JS assets, not further
generic runtime metadata scanning.

Sources:
https://github.com/DeadneM/Godfall-Enhanced-PC-Mod/tree/dev/h39-coherent-child-readonly
