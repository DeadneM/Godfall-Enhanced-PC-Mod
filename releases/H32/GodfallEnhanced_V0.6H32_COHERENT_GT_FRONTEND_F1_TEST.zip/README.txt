Godfall Enhanced V0.6H32 - COHERENT GT FRONTEND PROBE (F1 TEST)

READ-ONLY DEVELOPMENT DIAGNOSTIC. Does not yet unlock cosmetic skins.

INSTALL: back up the existing mod files. Extract ZIP entries DIRECTLY into
the directory with Aperion-Win64-Shipping.exe, preserving ue4ss/.

F1 = overlay (unchanged)
A = apply MacrosCosmetic appearance (unchanged H25)
B = restore original materials (unchanged H25)
C = Coherent GT and native menu interface watcher (NEW H32)

TEST:
1. In Sanctum, outside Hinterclaw's original skins menu, press F1->C ONCE.
2. Enter the original Hinterclaw skin selection screen and leave it open
   around 30-45 seconds. The watcher captures subsequent samples itself.
3. Send GodfallEnhancedBridge.log BEFORE game restart.

Expected H32_PROBE_ARMED, H32_PROBE_COUNTS, H32_PROBE_DIFF and
H32_CLASS_META. One scan every ~12 sec, max 10 total samples.
Do not use Method A during the diagnostic.

H31 detected WBP_GT_Test_C with a CoherentUIGTWidget_Persistent
in the live game. H32 tests whether this UI bridge changes during the
native cosmetic screen. Its role as the cosmetic UI is not yet proven.

Command fallback: COHERENT_PROBE (start) / STOP_COHERENT_PROBE (stop),
written to ue4ss/Mods/GodfallEnhancedBridge/bridge_command.txt.

Read-only. No save, backend entitlement, inventory or account changes.
https://github.com/DeadneM/Godfall-Enhanced-PC-Mod/tree/dev/h32-coherent-frontend-probe
