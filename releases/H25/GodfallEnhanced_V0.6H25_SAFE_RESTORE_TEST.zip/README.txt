Godfall Enhanced V0.6H25 SAFE MATERIAL RESTORE - TEST ONLY

Install:
Extract the FILES AND FOLDERS from this ZIP directly into the folder
containing Aperion-Win64-Shipping.exe, preserving ue4ss/Mods/.
Back up previous mod files before replacing.

Instructions:
- Equip default Hinterclaw, then start playing.
- F11 opens the existing development UI.
- Method A: apply the MacrosCosmetic skin.
- Method B: attempt safe restoration through original material assets.
- Method C: dump material slots.

H24 crash fix: on Method B, NEVER dereference the old original
MaterialInstanceDynamic pointers stored across GameThread calls.
H25 snapshots only asset names and loads stable parents for dynamic MIDs.
If safe material assets cannot be resolved, B refuses rather than risking
a crash. Base material restoration may not preserve the original dynamic
scalar/vector parameter overrides. For an exact reset use the game's
normal Valorplate equip UI after restoring the base appearance.

This is a TEST candidate, not a validated release.
H23 remains the validated canonical base. H25 does not add other skins.
H23 binary files dxgi.dll and GodfallEnhanced.asi are reused unchanged.
Source and test plan:
https://github.com/DeadneM/Godfall-Enhanced-PC-Mod/tree/dev/h25-safe-material-restore

Send GodfallEnhancedBridge.log with Method A and Method B results.
