Godfall Enhanced V0.6H37 - MULTI-PROBE ALCOVE + UI

EXPERIMENTAL DIAGNOSTIC ONLY. MACROSCOSMETIC STILL NOT UNLOCKED.

INSTALL: Back up H36, then extract complete ZIP into folder with
Aperion-Win64-Shipping.exe. Preserve ue4ss/ tree.

WHAT H37 TESTS:
1. Read map of live BP_ValorplateAlcove cosmetic tags (H36).
2. Try several read-only ways to decode Hinterclaw SoftClass assets.
3. Reflect only Hinterclaw Alcove class functions/properties.
4. Compare presence of two known Coherent/React UI widgets before
   and inside the game's original Hinterclaw cosmetics screen.

DO THIS:
  - Load into Sanctum and wait until loading COMPLETES.
  - Open F1 overlay, press C ONCE. This runs the grouped map probes.
  - Close mod overlay, open game's own Hinterclaw cosmetics screen.
  - Open F1 again, press C SECOND time. This compares UI state only.
  - Send GodfallEnhancedBridge.log BEFORE relaunching the game.
  - Look for H37_BOOT_MARKER=OK, H37_SOFTCLASS,
    H37_CLASS_AUDIT_END, H37_UI_SNAPSHOT_END sample=1/2.

A/B material apply/restore, original ASI/DXGI, H35 offline locator
and manual Coherent watcher command remain intact. Do not use A/B
for the H37 diagnostic.

NO TMap:Add or Remove, NO SetValorplateCosmetic action,
NO save edit, entitlement spoofing, backend or reward calls.
Potential UE4SS inspection crash risk: test only in loaded Sanctum.

Full source + documentation:
https://github.com/DeadneM/Godfall-Enhanced-PC-Mod/tree/dev/h37-multi-probe
