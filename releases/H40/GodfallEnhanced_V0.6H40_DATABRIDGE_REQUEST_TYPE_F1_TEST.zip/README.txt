Godfall Enhanced V0.6H40 - DATABRIDGE TYPE-ONLY TEST

EXPERIMENTAL BUILD - NATIVE COSMETIC UNLOCK IS NOT IMPLEMENTED.
This test uses two exact UE4SS Blueprint UFunction hooks and may
affect stability. Back up your existing mod before installing.

INSTALL: Extract complete ZIP beside Aperion-Win64-Shipping.exe
preserving ue4ss/ subfolders. Restart Godfall. The new log must
contain H40_BOOT_MARKER=OK.

TEST (THE ORDER MATTERS):
1. Enter fully loaded Sanctum and open original Hinterclaw SKINS MENU.
2. While in that original menu press F1 -> C ONCE to arm.
   H40_BRIDGE_ARMED confirms one or two exact hooks installed.
3. Close F1 overlay; move between three or four ordinary skins in
   Godfall's own menu and inspect their details as usual.
4. Open F1, press C AGAIN to disarm. Test automatically disarms
   after approximately 90 sec or 48 targeted callback events.
5. Send GodfallEnhancedBridge.log BEFORE restarting Godfall.

The hook logs ONLY sanitized request Type NAME for the widget.
It never reads Payload/Promise, never calls JS, changes ownership,
saves, inventory or account entitlements. No broad hooks or scans.
If no target is loaded, hooks won't install, and log explains why.
If it crashes, revert to H39; don't repeatedly reproduce a crash.

PRESERVED: H25 A/B apply/restore, F1 overlay, H35 locator,
H36 alcove-map audit (manual ALCOVE_MAP_AUDIT),
H39 Coherent child diagnostic (manual COHERENT_CHILD_AUDIT),
and original ASI/DXGI binaries.

Research basis: targeted FModel exports of WBP_GT_Settings and
WBP_GT_Base prove the OnDataBridgeIncomingRequest function signature.

Docs/code:
https://github.com/DeadneM/Godfall-Enhanced-PC-Mod/tree/dev/h40-targeted-databridge-types
