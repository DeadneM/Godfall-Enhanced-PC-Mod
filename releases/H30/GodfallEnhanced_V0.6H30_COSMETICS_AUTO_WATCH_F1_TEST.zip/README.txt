Godfall Enhanced V0.6H30 - ONE-CLICK Automatic Cosmetics UI Watch / F1

EXPERIMENTAL TEST: this does NOT unlock Gratitude or all cosmetics yet.
It detects potential changes to the live native cosmetics UI.

Back up previous files and extract all ZIP contents DIRECTLY into the
folder containing Aperion-Win64-Shipping.exe (including ue4ss/ tree).

F1 = open existing overlay
Method A = apply Gratitude MacrosCosmetic visuals (H25 logic, unchanged)
Method B = safe restore of captured materials (H25 logic, unchanged)
Method C = ARM AUTOMATIC COSMETICS UI WATCH, ONE CLICK ONLY

TEST:
1. Start Godfall. Go to the Sanctum, OUTSIDE Hinterclaw skins menu.
2. Press F1 then Method C ONCE. It creates a baseline and STARTS watching.
3. Open the normal Godfall Hinterclaw cosmetics menu.
4. Leave the menu open about 30-45 seconds. No second C press!
5. Send GodfallEnhancedBridge.log before restarting the game.

The UI monitor samples about every 12s, max 20 samples (~4 minutes).
Look for H30_UI_WATCH_ARMED, H30_UI_BASELINE_SAVED, H30_UI_DIFF.
Watch is read-only: no account entitlement, save, inventory mutations.
Heavy Unreal object snapshots may cause occasional brief stutter.

If F1 conflicts with game's UI, write UNLOCK_UI_AUDIT into
ue4ss/Mods/GodfallEnhancedBridge/bridge_command.txt once to start.
Write STOP_UI_WATCH to stop early.
A/B remain separately available, but DO NOT use A during this audit.

Development branch and detailed notes:
https://github.com/DeadneM/Godfall-Enhanced-PC-Mod/tree/dev/h30-cosmetics-auto-watch
