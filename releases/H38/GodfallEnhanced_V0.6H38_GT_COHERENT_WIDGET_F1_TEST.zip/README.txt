Godfall Enhanced V0.6H38 - GT Coherent Widget Diagnostic

EXPERIMENTAL READ-ONLY BUILD. NO NATIVE SKIN UNLOCK.

INSTALL:
Back up H37. Extract ZIP beside Aperion-Win64-Shipping.exe.
Preserve the ue4ss subfolders. Restart the game.

H37 FOUND:
WBP_GT_Test_C was absent in Sanctum baseline, then present in the
vanilla Hinterclaw skins view. WBP_Menu_Game_C stayed absent.

H38 TEST:
1. Enter the fully loaded Sanctum. Open F1 overlay and press C.
2. Close overlay and open the game's Hinterclaw skins screen.
3. Open F1 overlay and press C again.
4. Send GodfallEnhancedBridge.log before restarting.

H38_BOOT_MARKER=OK verifies installation. New markers:
H38_GT_PRESENT, H38_GT_FUNCTION, H38_GT_PROPERTY,
H38_GT_ROUTE, H38_VIEW_URL, H38_VIEW_PARENT,
H38_GT_PROBE_END. Only targeted names and redacted URL
categories are logged, never JS payloads or private data.

C now focuses on active WBP_GT_Test_C. Manual command
ALCOVE_MAP_AUDIT still runs the old H36/37 map audit.
COHERENT_PROBE still runs the previous frontend watcher.

Preserved: F1, A/B H25 apply/restore, H35 offline locator, same
GodfallEnhanced.asi and dxgi.dll. All files in install-ready ZIP.

No TMap changes, SetValorplateCosmetic, save/inventory changes,
account entitlements, backend calls or JS event injections.
UE4SS live reflection is guarded but has intrinsic crash risk.

Source/notes:
https://github.com/DeadneM/Godfall-Enhanced-PC-Mod/tree/dev/h38-coherent-gt-widget
