Godfall Enhanced V0.6H23 - Exact Material Equip TEST

PURPOSE
-------
This build abandons the H10-H20 loadout/session/hook tracing branch.
It performs no global hooks, no entitlement changes, no save edits, and no loadout/session mutation.

Hinterclaw MacrosCosmetic was verified from the cooked Blueprint dump to use the same Hinterclaw skeletal mesh with four material overrides:
  slot 0  MI_Macros_lower
  slot 1  MI_Macros_Fur
  slot 2  MI_Macros_Cloth
  slot 3  MI_Macros_Upper

TEST
----
1. Equip Hinterclaw (preferably the normal/default appearance).
2. Press F11.
3. Click method A. In H23 this means: Apply MacrosCosmetic Materials.
4. If the appearance changes to the Macros look, stop and report success.
5. Method B restores the four materials captured before A.
6. Method C only dumps the current four material slots.

IMPORTANT
---------
The old A/B/C labels in the native overlay are temporary. Only their bridge actions changed.
H23 uses no RegisterHook calls.

H23 change: resolves GetMaterial/SetMaterial by walking the live mesh class hierarchy; direct UE4SS method call fallback. No hooks/loadout/session.

H23 change: exact-name resolution only. GetMaterial(index) / SetMaterial(index, material) are called directly on the live CharacterMesh0 first, then exact reflected UFunctions are used only as fallback.
