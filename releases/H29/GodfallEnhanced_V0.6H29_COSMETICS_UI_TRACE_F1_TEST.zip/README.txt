Godfall Enhanced V0.6H29 - Native Cosmetics UI Trace / F1 TEST

This experimental build is NOT Unlock Gratitude or Unlock All.
Its purpose is to identify the missing *native cosmetics menu visibility*
and eligibility/ownership rules, instead of repeating native API dumps.

Install: back up the prior mod; extract every file and the ue4ss/ folder
DIRECTLY into the directory containing Aperion-Win64-Shipping.exe.

F1 - open/close the existing overlay (unchanged from H27/H28)
A - apply Gratitude MacrosCosmetic materials (H25)
B - restore original materials safely (H25)
C - capture a READ-ONLY cosmetics menu UI snapshot

TEST:
1. Remain in Sanctum, outside the vanilla cosmetic/skin selection screen.
2. Press F1 then Method C ONCE. Expect H29_UI_BASELINE_SAVED in the log.
3. Open the NORMAL Godfall Hinterclaw cosmetics selection menu.
4. Without closing that menu, press F1 then Method C again.
   If overlay interaction is impractical, write UNLOCK_UI_AUDIT into
   ue4ss/Mods/GodfallEnhancedBridge/bridge_command.txt while game is running.
5. Send GodfallEnhancedBridge.log BEFORE restarting the game.
   Look for H29_UI_DIFF, H29_UI_ADDED, H29_UI_FUNCTION and
   H29_UI_AUDIT_END snapshot=2.

No entitlement, SHiFT/EOS account, inventory or save modifications.
H28 discovered eligibility and acquisition APIs but no proven skin unlock.
Detailed instructions and source:
https://github.com/DeadneM/Godfall-Enhanced-PC-Mod/tree/dev/h29-native-cosmetics-ui-trace
