Godfall Enhanced V0.6H27 - Native Unlock Discovery / F1 overlay TEST

IMPORTANT: H27 is a read-only exploratory audit, NOT yet Unlock Gratitude
or Unlock All. No entitlement or save data is changed.

Install by extracting every file and the ue4ss/ folder DIRECTLY into the
Godfall executable folder (Aperion-Win64-Shipping.exe).
Backup older files before replacing.

F1 opens and closes the overlay; F11 is no longer the mod shortcut.
A: apply MacrosCosmetic appearance.
B: safely restore original base materials (H25 method).
C: dump materials and scan prioritized Aperion cosmetic/inventory/player
   classes for function and property names (read-only).
Press C ONCE, then send GodfallEnhancedBridge.log with
H27_UNLOCK_AUDIT_END so the next build can investigate real unlock state.

This is a test candidate. H23 is the established material equip base,
H25 restoration logic remains, and H27 changes the overlay key from F11
to F1 in the 64-bit GodfallEnhanced.asi. dxgi.dll remains unchanged.

Sources and notes:
https://github.com/DeadneM/Godfall-Enhanced-PC-Mod/tree/dev/h27-unlock-native-audit-f1
