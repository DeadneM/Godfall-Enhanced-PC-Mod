Godfall Enhanced V0.6H34 - REACT URL & CDO ROUTE PROBE (F1 TEST)

READ-ONLY EXPERIMENTAL BUILD. Does NOT unlock Gratitude or all skins.

Back up previous mod files. Extract ALL files at the ZIP root into the
game folder containing Aperion-Win64-Shipping.exe (including ue4ss/).

F1 = overlay (unchanged)
Method A = apply Gratitude MacrosCosmetic visual materials (H25 stable)
Method B = restore original materials (H25 stable)
Method C = inspect read-only Coherent & React URL metadata (H34)

H33 confirmed UE_DATABRIDGE as a JS event and discovered the
ReactCharacterSelectURL / ReactSettingsURL *properties* on the
WBP_Menu_Game_C class. H34 tries to read those properties from its
class default object using UE4SS UClass:GetCDO().
It also logs only safely sanitized view route filename/leaf and
scheme/host category. It does NOT log full URLs, JS payloads,
usernames, account tokens or private directories.

TEST:
1. In Sanctum OUTSIDE the vanilla Hinterclaw cosmetic screen,
   press F1 -> C exactly once.
2. Enter the NORMAL Hinterclaw cosmetics selection screen for
   about 30 seconds. The watcher runs up to 5 bounded snapshots.
3. Send GodfallEnhancedBridge.log BEFORE restarting the game.
   Look for H34_CDO_ROUTE, H34_CDO_FIELD_UNAVAILABLE,
   H33_VALUE field=URL_ROUTE, H32_PROBE_END.
4. Do not use Method A during the diagnostic.

This build does not change account/server entitlement or game saves.
The React character-select interface is not necessarily the skin
ownership interface. We will verify that relationship, not assume it.

More information and research notes:
https://github.com/DeadneM/Godfall-Enhanced-PC-Mod/tree/dev/h34-react-route-cdo-probe
