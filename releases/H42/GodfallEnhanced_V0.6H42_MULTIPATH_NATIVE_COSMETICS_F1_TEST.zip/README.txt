Godfall Enhanced H42 MULTIPATH (EXPERIMENTAL, NOT YET VALIDATED)
Backup H41. Extract entire ZIP beside Aperion-Win64-Shipping.exe.
Equip Hinterclaw, stand by Hinterclaw Alcove in loaded Sanctum.
F1 -> C ONE time: visual Macros H25 + try temporary alcove Map,
APCosmeticsManager native override, BP_ValorplateAlcove native select.
Inspect the ORIGINAL Hinterclaw cosmetic menu: is Macros listed?
F1 -> C again BEFORE leaving Sanctum for best-effort rollback.
A/B visual material methods remain unchanged.
Do not expect second C to perfectly restore Alcove preview: reload
Sanctum if visuals remain changed. Native calls can crash the game.
No account entitlement, reward grant, loot persistence, save mutation
or server operations. ASI/DXGI and H35 locator are unchanged.
https://github.com/DeadneM/Godfall-Enhanced-PC-Mod/tree/dev/h42-multipath-local-cosmetics
