Godfall Enhanced V0.6H45 - NATIVE MACROS ASSET + TAG REPAIR

EXPERIMENTAL, NATIVE UNLOCK STILL NOT VALIDATED.
H44 user test: F6 applied four Macros materials twice and F10 restored
four assets; F7/F8 stopped at missing Macros Blueprint class and F9
stopped because global FName() is absent in this UE4SS build.

H45 fixes:
- UE4SS StaticFindObject WITHOUT BlueprintGeneratedClass prefix.
- Uses precise FModel Blueprint generated class/object/package paths.
- Attempts to use real Macros UClass default GameplayTag when loaded.
- F9 no longer depends on FName(); uses native CDO GameplayTag.
- F8 uses native CDO GameplayTag FName as request identifier.
- No new hooks, no auto-chain, no reward/account/save modifications.

Independent controls (same as H44):
 F6 = validated H25 visual Macros (safe-ish; temporary)
 F7 = try local Alcove TMap:Add, high crash risk
 F8 = try local CosmeticsManager override, high crash risk
 F9 = try native Alcove SetValorplateCosmetic, high crash risk
 F10 = best effort restore of completed modifications
 F1 A/B = unchanged H25 material commands; C = help only

Installation: back up H44, extract full ZIP next to game EXE.
Prefer ONE test with F9 only after entering Sanctum with Hinterclaw.
Do not repeat F6/F10 visual checks merely to confirm known behavior.
Do not retry ANY key that crashes. Native pcall cannot catch C++ faults.
If new skin does not appear in vanilla selection, this isn't an unlock.
No extra loot, entitlements, account, server or saved data mutations.
https://github.com/DeadneM/Godfall-Enhanced-PC-Mod/tree/dev/h45-native-asset-tag-repair
