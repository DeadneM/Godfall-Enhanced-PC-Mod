Godfall Enhanced V0.6H35 - OFFLINE FRONTEND RESOURCE LOCATOR

EXPERIMENTAL: resource discovery, NOT an unlocker. H34 game behavior
is preserved unchanged except for version / H35_BOOT_MARKER banners.

INSTALL:
Extract all ZIP contents DIRECTLY into the directory containing
Aperion-Win64-Shipping.exe, preserving the ue4ss/ subfolders.
Back up any previous mod installation first.

NEW IN H35:
Run_GodfallFrontendLocator.cmd
GodfallFrontendLocator.ps1

TEST H35: CLOSE GODFALL FIRST.
Double-click Run_GodfallFrontendLocator.cmd from that directory.
Then send only GodfallFrontendAssetsReport.txt, written beside the
launcher. This scans local game installation assets to locate possible
React/Coherent interface files / PAK containers. It reports relative
file paths and marker NAMES, NOT JS content, private data or hostnames.
It does NOT unpack/modify PAKs, edit saves, connect to the network,
or change Windows' persistent PowerShell execution policy.
PowerShell is run under a temporary process-only execution-policy bypass.
You may inspect the readable .ps1 source before launching.

F1 overlay & H34 in-game read-only C diagnostic remain available.
A/B H25 visual material apply/restore remain unchanged.
Do not retest the full H34 audit unless needed. H35 test is OFFLINE.

Prior findings: WBP_Menu_Game_C React character-select / settings
route class defaults; UE_DATABRIDGE event name. These do not prove
native skin ownership. Gratitude MacrosCosmetic is still NOT natively
unlocked. Next step is actual bundled frontend asset analysis.

Source / technical notes:
https://github.com/DeadneM/Godfall-Enhanced-PC-Mod/tree/dev/h35-offline-frontend-locator
