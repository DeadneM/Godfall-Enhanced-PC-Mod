Godfall Enhanced V0.6H33 - Coherent GT Runtime Value Probe (F1)

EXPERIMENTAL READ-ONLY TEST: Unlock Gratitude / Unlock All are NOT implemented.

Back up prior mod, then extract all ZIP content DIRECTLY into the
Aperion-Win64-Shipping.exe folder, preserving ue4ss/ structure.

F1 overlay unchanged.
Method A: visually apply Gratitude MacrosCosmetic, H25 stable logic.
Method B: restore materials, H25 stable logic.
Method C: one press starts read-only Coherent GT runtime value scans.

H32 proved this game launches WBP_GT_Test_C and its
CoherentUIGTWidget_Persistent, with transient JS-event/payload objects.
H33 only reads three reflected FString properties:
  CoherentUIGTComponent.URL
  CoherentUIGTSettings.CoUIResourcesRoot
  CoherentUIGTJSPayload.EventName
No JS payload argument/content, account data, save or entitlement mutation.
The output redacts full URLs and filters unsafe event names.

TEST: In Sanctum outside native Hinterclaw skins screen, F1 -> C once.
Then open the ORIGINAL Hinterclaw cosmetics menu for 30-45 seconds.
Send GodfallEnhancedBridge.log BEFORE restart, look for
H33_VALUE_SUMMARY, H33_VALUE, H33_TARGET_PROPERTY and H32_PROBE_DIFF.
Do not use A during this test. Max 10 samples, ~12-second interval.

Alternative command in ue4ss/Mods/GodfallEnhancedBridge/bridge_command.txt:
COHERENT_PROBE to start, STOP_COHERENT_PROBE to stop.

Source and cumulative notes:
https://github.com/DeadneM/Godfall-Enhanced-PC-Mod/tree/dev/h33-coherent-readonly-values
