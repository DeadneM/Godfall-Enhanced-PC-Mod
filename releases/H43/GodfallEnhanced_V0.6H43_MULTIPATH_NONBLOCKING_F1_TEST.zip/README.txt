Godfall Enhanced V0.6H43 - NONBLOCKING MULTIPATH MACROS
EXPERIMENTAL BUILD. This is NOT proof of a native skin unlock.

H42 USER TEST: stopped at NO_MACROS_CLASS before every trial.
H43 FIX: each native technique is independent; known-good visual H25
executes FIRST, even if class loading fails. More class loading routes
are attempted, with a separate native class/Tag status line.
The cosmetic FunctionLibrary is an alternative to CosmeticsManager.
Black skin is NEVER substituted for missing Macros class.

BACK UP H42 before installation. Extract ZIP beside
Aperion-Win64-Shipping.exe, keeping ue4ss folders.
Equip Hinterclaw and open a fully loaded Sanctum near its alcove.
F1 -> C once: visual Macros, native class/tag loading, Alcove map,
CosmeticsManager or FunctionLibrary local override, native preview.
Inspect the ORIGINAL Hinterclaw skins menu: is Macros selectable?
F1 -> C second time before traveling for BEST-EFFORT cleanup.
If native preview remains changed, reenter Sanctum.

Original H25 A/B visual methods and F1 remain intact.
No saved inventory/rewards, no account entitlement spoof,
no remote calls, no save modification. Native calls may crash.
Full notes:
https://github.com/DeadneM/Godfall-Enhanced-PC-Mod/tree/dev/h43-multipath-nonblocking
