Godfall Enhanced V0.6H26 - READ-ONLY Unlock Discovery TEST

Install:
Extract contents of this ZIP DIRECTLY into the game exe folder, keeping
ue4ss/Mods/GodfallEnhancedBridge/scripts/main.lua in its normal location.
Back up your prior files first. dxgi.dll and GodfallEnhanced.asi are unchanged
from H23.

Play:
- Start Godfall, equip Hinterclaw, open the existing F11 overlay.
- Method A: apply MacrosCosmetic (H25 function unchanged).
- Method B: restore materials with the H25 safe parent-asset fallback.
- Method C: dump material slots AND perform the new read-only unlock audit.
  Press Method C ONCE and read GodfallEnhancedBridge.log.
- Optional advanced command: put UNLOCK_AUDIT in
  ue4ss/Mods/GodfallEnhancedBridge/bridge_command.txt (consumed by bridge).

Look for H26_UNLOCK_AUDIT_BEGIN, H26_CLASS, H26_FUNCTION,
H26_PROPERTY, H26_UNLOCK_AUDIT_END in the log.
Send the log so we can identify the *actual* native unlock state path.

IMPORTANT: H26 DOES NOT unlock Gratitude or All cosmetics yet.
It only discovers relevant function/property names, with NO hooks and
NO entitlement or save modifications. It also does not substitute
visual overrides for actual cosmetic ownership.

Sources and test instructions:
https://github.com/DeadneM/Godfall-Enhanced-PC-Mod/tree/dev/h26-unlock-discovery
