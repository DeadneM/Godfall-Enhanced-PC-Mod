Godfall Enhanced V0.6H36 - VALORPLATE ALCOVE INSTANCE MAP AUDIT

EXPERIMENTAL DIAGNOSTIC; NOT A SKIN UNLOCK.

INSTALL: Backup your H35 files, then extract this ZIP into the folder
containing Aperion-Win64-Shipping.exe. Preserve the ue4ss folder tree.

NEW: Method C (F1 overlay) does a one-shot READ-ONLY lookup of live
BP_ValorplateAlcove_C actors in the Sanctum, and reads their
CosmeticTagToPlayerSkin map (GameplayTag -> SoftClass BP_Player).

TEST: In the Sanctum, WAIT FOR LOADING TO FINISH, then press
F1 -> C ONCE. Do not press C while loading or travelling.
Send GodfallEnhancedBridge.log before restarting. The boot must say
H36_BOOT_MARKER=OK. Check H36_ALCOVE_AUDIT_END.

Existing A/B H25 visual apply/restore and F1 overlay are preserved.
The old H34 Coherent watcher can be triggered by manually writing
COHERENT_PROBE into bridge_command.txt (C now tests alcoves).
The H35 offline resource locator scripts remain included.
dxgi.dll and GodfallEnhanced.asi are identical to H35/H34.

No cosmetic ownership is modified. No SetValorplateCosmetic, reward,
network/backend, or save changes. Native UE4SS inspections still have
inherent crash risk, especially during level loads.

MacrosCosmetic is NOT YET unlocked in the original menu.
See https://github.com/DeadneM/Godfall-Enhanced-PC-Mod/tree/dev/h36-valorplate-instance-map
