Godfall Enhanced V0.6H31 - NATIVE UI / SKIN CATALOG FOCUS (F1 TEST)

Experimental read-only diagnostic. Unlock Gratitude / Unlock All are NOT yet implemented.

INSTALL: back up your old mod. Extract ALL files straight into the
folder containing Aperion-Win64-Shipping.exe, preserving ue4ss/ paths.

F1 - open the unchanged overlay
A - visually apply MacrosCosmetic (H25 base, unchanged)
B - restore original materials (H25 base, unchanged)
C - automatic read-only watcher for native cosmetic UI (H31)

TEST:
1. In Sanctum OUTSIDE the Hinterclaw skin menu, press F1 then C ONCE.
2. Open the real game's Hinterclaw cosmetics screen and keep it open
   around 30-45 seconds. No need for a second C press.
3. Close the menu. Send GodfallEnhancedBridge.log BEFORE game restart.
   Seek H31_UI_DIFF, H31_WIDGET_ADDED, H31_HINTERCLAW_SKIN_CLASS_ADDED.

H31 improves H30 by ranking UMG/UserWidget/WBP_ and UI/menu assets,
logging up to 160 ranked additions and removals per sample, and
tracking newly loaded Hinterclaw skin Blueprint classes explicitly.
12 samples at ~12-second intervals maximum. May briefly stutter on
large object scans. Read-only, no unlock/account/save modification.
Do not use Method A during this audit.

Fallback: write UNLOCK_UI_AUDIT into
ue4ss/Mods/GodfallEnhancedBridge/bridge_command.txt to arm the watcher,
or STOP_UI_WATCH to stop.

Source, readme and investigation notes:
https://github.com/DeadneM/Godfall-Enhanced-PC-Mod/tree/dev/h31-native-ui-catalog-focus
