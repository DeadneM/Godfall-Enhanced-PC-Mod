Godfall Enhanced V0.6H41 - SINGLE DATABRIDGE REQUEST TYPE TRACE

EXPERIMENTAL DEBUG BUILD. THIS IS NOT AN UNLOCKER.

H40 TEST RESULT: DataBridge captured 48 events and unregistered
both BASE / SETTINGS hooks with errors=0; request names included
UE_ROUTE_UI, UE4_SHOW_LOADOUT_VISUAL_REQUEST and
UE4_SHOW_LOADOUT_WEAPON_VISUAL_REQUEST. Both hooks duplicated
nearly identical request streams and exhausted the budget early.

H41 CHANGES:
- Exactly ONE UFunction hook (WBP_GT_Base OnDataBridgeIncomingRequest).
- Up to 160 captured callbacks or 90 seconds, whichever is first.
- Sanitized Type names and event order; frequency totals upon stop.
- No access to the Payload, Promise, JS, credentials or user account.
- No return overrides, TMap changes, saves or entitlement mutations.
- H25 visual A/B, F1 overlay and H35 locator are retained.
- Original GodfallEnhanced.asi and dxgi.dll are unchanged.

INSTALL:
Back up H40, then extract this complete ZIP beside
Aperion-Win64-Shipping.exe, retaining the ue4ss folder structure.
Restart Godfall. Look for H41_BOOT_MARKER=OK in the bridge log.

TEST:
1. Open original skin menu on a Valorplate with UNLOCKED skins.
2. Press F1 -> C once. Confirm H41_BRIDGE_ARMED hooks=1.
3. Close overlay and switch between several owned skins.
4. Press F1 -> C again to stop BEFORE the 90-second limit.
   If it auto-stopped, DO NOT press C again (that restarts capture).
5. Send GodfallEnhancedBridge.log before game restart.
Find H41_BRIDGE_EVENT, H41_BRIDGE_STOP, H41_BRIDGE_SUMMARY.

If hook instability occurs, stop testing and return to H39.
Full technical notes:
https://github.com/DeadneM/Godfall-Enhanced-PC-Mod/tree/dev/h41-single-hook-event-summary
